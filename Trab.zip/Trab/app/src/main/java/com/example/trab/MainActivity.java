package com.example.trab;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ReceitaDAO receitaDAO;
    private ListView listView;
    private Button cadastrarButton, consultarButton, detalhesButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando os componentes
        receitaDAO = new ReceitaDAO(this);
        listView = findViewById(R.id.listView);
        cadastrarButton = findViewById(R.id.cadastrarButton);
        consultarButton = findViewById(R.id.consultarButton);
        detalhesButton = findViewById(R.id.detalhesButton);

        // Configurando o ListView
        List<Receita> receitas = receitaDAO.listarReceitas();
        ReceitaAdapter adapter = new ReceitaAdapter(this, receitas);
        listView.setAdapter(adapter);

        // Click no item do ListView
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Receita receita = (Receita) parent.getItemAtPosition(position);
            Intent intent = new Intent(MainActivity.this, DetalhesReceitaActivity.class);
            intent.putExtra("id", receita.getId()); // Passando o ID da receita para a próxima tela
            startActivity(intent);
        });

        // Ação para o botão "Cadastrar Receita"
        cadastrarButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CadastrarReceitaActivity.class);
            startActivity(intent);
        });

        // Ação para o botão "Consultar Receita"
        consultarButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ConsultarReceitaActivity.class);
            startActivity(intent);
        });

        // Ação para o botão "Detalhes Receita"
        detalhesButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DetalhesReceitaActivity.class);
            startActivity(intent);
        });
    }
}
