package com.example.trab;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastrarReceitaActivity extends AppCompatActivity {
    private EditText nomeEditText, descricaoEditText;
    private ReceitaDAO receitaDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastrar_receita_activity);

        nomeEditText = findViewById(R.id.nomeEditText);
        descricaoEditText = findViewById(R.id.descricaoEditText);
        receitaDAO = new ReceitaDAO(this);
    }

    public void onSalvar(View view) {
        String nome = nomeEditText.getText().toString();
        String descricao = descricaoEditText.getText().toString();

        if (!nome.isEmpty() && !descricao.isEmpty()) {
            Receita receita = new Receita(0, nome, descricao);
            receitaDAO.inserirReceita(receita);
            Toast.makeText(this, "Receita cadastrada!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Preencha todos os campos!", Toast.LENGTH_SHORT).show();
        }
    }
}
