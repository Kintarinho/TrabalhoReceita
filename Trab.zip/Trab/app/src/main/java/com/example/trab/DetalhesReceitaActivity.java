package com.example.trab;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetalhesReceitaActivity extends AppCompatActivity {
    private TextView nomeTextView, descricaoTextView;
    private ReceitaDAO receitaDAO;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detalhes_receita_activity);

        nomeTextView = findViewById(R.id.nomeTextView);
        descricaoTextView = findViewById(R.id.descricaoTextView);
        receitaDAO = new ReceitaDAO(this);

        int id = getIntent().getIntExtra("id", -1);
        if (id != -1) {
            Receita receita = receitaDAO.buscarReceitaPorId(id);
            if (receita != null) {
                nomeTextView.setText(receita.getNome());
                descricaoTextView.setText(receita.getDescricao());
            }
        }
    }
}
