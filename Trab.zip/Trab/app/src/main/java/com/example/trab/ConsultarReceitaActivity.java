package com.example.trab;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ConsultarReceitaActivity extends AppCompatActivity {
    private EditText idEditText;
    private ReceitaDAO receitaDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.consultar_receita_activity);

        receitaDAO = new ReceitaDAO(this);
    }

    public void onBuscar(View view) {
        String idStr = idEditText.getText().toString();
        if (!idStr.isEmpty()) {
            int id = Integer.parseInt(idStr);
            Receita receita = receitaDAO.buscarReceitaPorId(id);
            if (receita != null) {
                Toast.makeText(this, "Receita encontrada: " + receita.getNome(), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Receita não encontrada!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
