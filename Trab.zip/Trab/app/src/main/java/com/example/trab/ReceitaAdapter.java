package com.example.trab;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class ReceitaAdapter extends ArrayAdapter<Receita> {
    public ReceitaAdapter(Context context, List<Receita> receitas) {
        super(context, 0, receitas);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Obter o item atual
        Receita receita = getItem(position);

        // Reutilizar a view existente ou criar uma nova
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_main, parent, false);
        }

        // Configurar os dados no layout
        TextView nomeTextView = convertView.findViewById(R.id.nomeTextView);
        TextView descricaoTextView = convertView.findViewById(R.id.descricaoTextView);

        if (receita != null) {
            nomeTextView.setText(receita.getNome());
            descricaoTextView.setText(receita.getDescricao());
        }

        return convertView;
    }
}