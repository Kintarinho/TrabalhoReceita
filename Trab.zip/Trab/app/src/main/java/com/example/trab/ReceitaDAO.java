package com.example.trab;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ReceitaDAO {
    private SQLiteDatabase db;

    public ReceitaDAO(Context context) {
        db = new DBHelper(context).getWritableDatabase();
    }

    public long inserirReceita(Receita receita) {
        ContentValues values = new ContentValues();
        values.put("nome", receita.getNome());
        values.put("descricao", receita.getDescricao());
        return db.insert("receitas", null, values);
    }

    public List<Receita> listarReceitas() {
        List<Receita> receitas = new ArrayList<>();
        Cursor cursor = db.query("receitas", null, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex("id"));
                @SuppressLint("Range") String nome = cursor.getString(cursor.getColumnIndex("nome"));
                @SuppressLint("Range") String descricao = cursor.getString(cursor.getColumnIndex("descricao"));
                receitas.add(new Receita(id, nome, descricao));
            }
            cursor.close();
        }
        return receitas;
    }

    public Receita buscarReceitaPorId(int id) {
        Cursor cursor = db.query("receitas", null, "id=?", new String[]{String.valueOf(id)}, null, null, null);
        if (cursor != null && cursor.moveToNext()) {
            @SuppressLint("Range") String nome = cursor.getString(cursor.getColumnIndex("nome"));
            @SuppressLint("Range") String descricao = cursor.getString(cursor.getColumnIndex("descricao"));
            cursor.close();
            return new Receita(id, nome, descricao);
        }
        return null;
    }
}
